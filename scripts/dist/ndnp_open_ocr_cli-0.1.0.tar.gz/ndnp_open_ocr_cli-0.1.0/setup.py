# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ndnp_open_ocr_cli']

package_data = \
{'': ['*']}

install_requires = \
['boto3==1.23.10', 'click==8.0.1', 'requests==2.26.0', 'tqdm==4.64.1']

entry_points = \
{'console_scripts': ['noo = ndnp_open_ocr_cli.cli:cli']}

setup_kwargs = {
    'name': 'ndnp-open-ocr-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Library of Congress',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
